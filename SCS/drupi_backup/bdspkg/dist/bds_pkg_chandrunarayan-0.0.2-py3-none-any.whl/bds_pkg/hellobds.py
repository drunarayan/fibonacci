# Say Hello
def bdsworld():
    print("Hello, BDS!")
mybdshost = 'bupiX'
