<h1>Table of Contents<span class="tocSkip"></span></h1>
<div class="toc"><ul class="toc-item"><li><span><a href="#FSCR-BUSH-DIGITAL-SPECTROMETER-JUPYTER-NOTEBOOK" data-toc-modified-id="FSCR-BUSH-DIGITAL-SPECTROMETER-JUPYTER-NOTEBOOK-1"><span class="toc-item-num">1&nbsp;&nbsp;</span>FSCR BUSH DIGITAL SPECTROMETER JUPYTER NOTEBOOK</a></span><ul class="toc-item"><li><span><a href="#BDS-Header-Block" data-toc-modified-id="BDS-Header-Block-1.1"><span class="toc-item-num">1.1&nbsp;&nbsp;</span>BDS Header Block</a></span></li><li><span><a href="#Importing-Libraries-and-Notebooks" data-toc-modified-id="Importing-Libraries-and-Notebooks-1.2"><span class="toc-item-num">1.2&nbsp;&nbsp;</span>Importing Libraries and Notebooks</a></span></li><li><span><a href="#BDS-Configuration-Parameters" data-toc-modified-id="BDS-Configuration-Parameters-1.3"><span class="toc-item-num">1.3&nbsp;&nbsp;</span>BDS Configuration Parameters</a></span></li><li><span><a href="#BDS-File-Output-Names" data-toc-modified-id="BDS-File-Output-Names-1.4"><span class="toc-item-num">1.4&nbsp;&nbsp;</span>BDS File Output Names</a></span></li><li><span><a href="#Creating-the-Spectrometer-Camera-Object" data-toc-modified-id="Creating-the-Spectrometer-Camera-Object-1.5"><span class="toc-item-num">1.5&nbsp;&nbsp;</span>Creating the Spectrometer Camera Object</a></span></li><li><span><a href="#Obtaining-the-Raw-Image-of-the-Spectrum" data-toc-modified-id="Obtaining-the-Raw-Image-of-the-Spectrum-1.6"><span class="toc-item-num">1.6&nbsp;&nbsp;</span>Obtaining the Raw Image of the Spectrum</a></span></li><li><span><a href="#Draw-Visual-Aperture-and-Measure-Emission-Spectral-Peaks" data-toc-modified-id="Draw-Visual-Aperture-and-Measure-Emission-Spectral-Peaks-1.7"><span class="toc-item-num">1.7&nbsp;&nbsp;</span>Draw Visual Aperture and Measure Emission Spectral Peaks</a></span></li><li><span><a href="#Display-Emission-Spectrum-and-Compare-with-NIST-Standard-values" data-toc-modified-id="Display-Emission-Spectrum-and-Compare-with-NIST-Standard-values-1.8"><span class="toc-item-num">1.8&nbsp;&nbsp;</span>Display Emission Spectrum and Compare with NIST Standard values</a></span></li></ul></li></ul></div>

# FSCR BUSH DIGITAL SPECTROMETER JUPYTER NOTEBOOK

## BDS Header Block


```python
# BUSH DIGITAL SPECTROMETER SOFTWARE INTERACTIVE VERSION
# Author - Chandru Narayan
# TEMPLATE FOR FCSR STUDENTS
# CN Version_12i  11/25/2019 cloned from automated version v11
#
#    120219 CN "Added function call to print BDS parameters"
#    120419 CN "Added function call to compute peaks in the spectrum wavelengths"
#    120619 CN "Added cell for bdscfg parms"
#    120619 CN "Added Try-Except Block for creating Camera Objects"

```

## Importing Libraries and Notebooks


```python
import import_ipynb
from IPython.core.display import Image
from IPython.core.display import display
from IPython.display import IFrame
#import PIL
from PIL import Image as pilimg
from PIL import ImageDraw as pildraw
from PIL import ImageFont as pilfont
import picamera
import os, sys
import time
from datetime import datetime

class StopExecution(Exception):
    def _render_traceback_(self):
        pass
    
```


```python
# BUSH LIBRARY FUNCTIONS FOR BUSH DIGITAL SPECTROMETER SOFTWARE INTERACTIVE VERSION
# Author - Chandru Narayan
# TEMPLATE FOR FCSR STUDENTS
# CN Version_11i  12/1/2019 cloned from automated version v11
# IMPORT BDSLIB AND BDSCFG HERE
import bdslibv2
```

## BDS Configuration Parameters


```python
###
#    BUSH DIGITAL TELESCOPE SOFTWARE CONFIG SECTION
#    TO BE USED IN THE INTERACTIVE VERSION ONLY
#    FOR DETAILED DESCRIPTION OF PARMS SEE BDS CONFIG DOC 
###

#
# NAMING
#
source = 'LED'      
element = 'LED'                    
desc = 'SPECTRUM FROM A BRIGHT LED LIGHT SOURCE' 

#
# CAMERA
#
shutter = 10000

#
# CALIBRATION
#
wavelength_factor = 0.98
spectrum_angle = -0.01
slit_topadj = 50
slit_botadj = 0

#
# PLOTS
#
samp_th = 0.2
wlen_th = 25


```

## BDS File Output Names


```python
# STEP 1. SETUP FILE BASENAMES WITH TIMESTAMPS
#       setup the source or basename for files
#       make it indicative of the spectrum you are taking
#       keep it short but meaningful. Do not name "a1" etc!
#source = 'cfls'

# Filenames be appended with date and time 
# such that they will not be overwritten 
now = datetime.now()
name = source + now.strftime("%m%d%H%M%S")
raw_filename = name + "_raw"
ovl_filename = name + "_ovl"
cht_filename = name + "_cht"
tbl_filename = name + "_tbl"
par_filename = name + "_par"
pks_filename = name + "_pks"
```


```python
################## STUDENT TO ADD EDITS BELOW ################################
## WRITE A STATEMENT TO PRINT THE 4 OUTPUT NAMES FROM THE BDS SOFTWARE TO FAMILIARIZE YOURSELF

print(raw_filename)
print(ovl_filename)
print(cht_filename)
print(tbl_filename)
print(par_filename)
print(pks_filename)
```

    LED0731122116_raw
    LED0731122116_ovl
    LED0731122116_cht
    LED0731122116_tbl
    LED0731122116_par
    LED0731122116_pks



```python
################## STOP HERE STUDENT/INSTRUCTOR TO VALIDATE STEP 1 ####################
## VALIDATE THE NAMES OF FILES TO BE CREATED - DO THEY LOOK RIGHT ??? ##

# DO NOT GO FORWARD UNTIL INSTRUCTOR VALIDATES
```

## Creating the Spectrometer Camera Object


```python
# STEP 2. CREATE THE CAMERA OBJECT
#         CAPTURE THE RAW SPECTRUM IMAGE
#         THIS WILL BE EXAMINED FOR ANY ADJUSTMENTS NEEDED
#         FOR EXAMPLE IMAGE BRIGHTNESS LIGHT LEAKAGE ETC
#         DISPLAY CAPTURED IMAGE
```


```python
#         Get camera object. Note that this can only be executed ONCE per run
#         YOU SHOULD NOT RUN IT AGAIN UNLESS THE CAMERA IS CLOSED WHICH
#         THIS STATEMENT IS AT THE VERY BOTTOM OF THIS FILE
try:
    camera = picamera.PiCamera()
except:
    print("Exception in opening camera object")
    print("Closing and Recreating Camera Object")
    camera.close()
    camera = picamera.PiCamera()
finally:
    print("Camera object created")

```

    Camera object created



```python
#          Set the shutter speed of the camera.
#          Use 100000 for a medium bright spectrum
#shutter = 5000
camera.shutter_speed = shutter
#         flip the image laterally as my analysis software reads with slit on the right!
camera.hflip = True
#         capture image with a predetermined size suitable for pixel counting analysis
raw_jpg_filename = raw_filename + ".jpg"
camera.capture(raw_jpg_filename, resize=(1296, 972))
#camera.capture(raw_jpg_filename, resize=(800, 600))
```

## Obtaining the Raw Image of the Spectrum


```python
#       view image and apply putty or tape inside spectroscope to prevent light leakage
#       remember - image is flipped laterally from left right!
display(Image(raw_jpg_filename))
bdslibv2.display_bds_params(name,desc,shutter,slit_topadj,slit_botadj,spectrum_angle,wavelength_factor,samp_th,wlen_th)
```


![jpeg](output_18_0.jpeg)


    Title:		 SPECTRUM FROM A BRIGHT LED LIGHT SOURCE
    BDS parameters used for this run:
    Spectrum Base Name is          	 LED0731122116
    Camera Shutter is:             	 10000
    Slit Top Adjustment is:        	 50
    Slit Bottom Adjustment is:     	 0
    Camera Spectrum Angle is:      	 -0.01
    Camera Wavelength Factor is:   	 0.98
    Amplitude Threshold is:        	 0.2
    Wavelength Threshold is:       	 25



```python
################## STOP HERE STUDENT/INSTRUCTOR TO VALIDATE STEP 2 ####################
## DID THE IMAGE APPEAR ??
## IS THE IMAGE OF THE SPECTRUM VISIBLE ??
## IS THE IMAGE FLIPPED LATERALLY ?
## DOES THE SLIT LOOK OVER EXPOSED ??
## DOES THE SPECTRUM LOOK TOO DIM ??

# DO NOT GO FORWARD UNTIL INSTRUCTOR VALIDATES
```

## Draw Visual Aperture and Measure Emission Spectral Peaks 


```python
# STEP 3. PROCESS THE IMAGE AND LOCATE THE SLIT (APERTURE)
#         READ RAW JPG FILE OBTAINED IN A PIXEL ARRAY
#         RECORD THE PIXEL WIDTH AND HEIGHT
#         NARROW THE PIXEL WINDOW FOR SLIT TOP AND BOTTOM
#         FOR EXAMPLE IMAGE BRIGHTNESS LIGHT LEAKAGE ETC
#         DISPLAY CAPTURED IMAGE
```


```python
#         READ RAW JPG FILE OBTAINED IN A PIXEL ARRAY
im = pilimg.open(raw_jpg_filename)
pic_pixels = im.load()
#         record the pixel width and height
width = im.size[0]
height = im.size[1]
print("width is %d, height is %d" % (width, height))
#        The slit needs to be shortened in height at times due to light leakage
#        inside spectrometer. This small adjustment can be made here. 
#        bigger negative numbers for smaller for bottom slit 
#        bigger positive numbers for smaller top slit 
#        for daylight or bright spectrum we need to narrow the slit greatly.
#        default values are set above
#        Adjust and uncomment below if you need
#slit_topadj = 130
#slit_botadj = -260

#        call library function to find the aperture in the raw image (pixel array)
aperture = bdslibv2.find_aperture(pic_pixels, width, height, slit_topadj, slit_botadj)
#        draw the aperture
draw = pildraw.Draw(im)
bdslibv2.draw_aperture(aperture, draw)

```

    width is 1296, height is 972
    aperture_x b4 avg is: 786
    aperture_x1 is: 785
    aperture_x2 is: 787
    avg aperture_x is: 786.0
    spectrum_top is 2 spectrum bottom is 644
    adj spectrum_top is 52 adj spectrum bottom is 644



```python
#        Draw scan line using the Spectrum angle
#        This is the angle that the camera and diffration grating makes with the light path
#        The Spectrum Angle trignometric tangent of the angle the camera and diffration grating makes 
#        with the line of sight to the entry slit. This usually does not need to be changed very much 
#        as it manipulates where in the observation area the spectrum falls. It only needs to be 
#        approximate such that pixel counter can find it
#        default values are set above
#        Adjust and uncomment below if you need
#spectrum_angle = 0.01
#        draw the scan lline
bdslibv2.draw_scan_line(aperture, draw, spectrum_angle)
```


```python
#        The wavelength_factor is the variable used for calibrating the spectroscope such that 
#        the calibration spectral line matches the known standard for that emission spectrum
#        The wavelength_factor is close to 0.90 for the 1000 lines/mm diffration grating
#        The wavelength_factor is close to 0.60 for the 500 lines/mm diffration grating
#        default values are set above
#        Adjust and uncomment below if you need
#wavelength_factor = 0.7 
try:
    results, max_result = bdslibv2.draw_graph(draw, pic_pixels, aperture, spectrum_angle, wavelength_factor)
except:
    camera.close()
    print("Exception while creating an aperture")
    print("This run **** TERMINATED PREMATURELY **** ...")
    print("Maybe the result of misaligned light path a very dim spectrum")
    print("Adjust Light Path Alignment OR Increase Shutter parameter and try again")    
    raise StopExecution
else:
    print("Producing graphical result")
```

    Producing graphical result



```python
#        Display actual and ideal targets for camera exposure corrections
bdslibv2.inform_user_of_exposure(max_result)
```

    ideal exposure between 0.15 and 0.30
    exposure= 1.838300813746848
    consider reducing shutter time
    



```python
#       Create the spectrum image overlaid with aperture and scan line
ovl_jpg_filename = ovl_filename + ".jpg"
bdslibv2.save_image_with_overlay(im, ovl_jpg_filename)

```


```python
#       View the Overlaid image fix parameters and rerun STEP 3 ONLY from the beginning as needed
display(Image(ovl_jpg_filename))
bdslibv2.display_bds_params(name,desc,shutter,slit_topadj,slit_botadj,spectrum_angle,wavelength_factor,samp_th,wlen_th)
```


![jpeg](output_27_0.jpeg)


    Title:		 SPECTRUM FROM A BRIGHT LED LIGHT SOURCE
    BDS parameters used for this run:
    Spectrum Base Name is          	 LED0731122116
    Camera Shutter is:             	 10000
    Slit Top Adjustment is:        	 50
    Slit Bottom Adjustment is:     	 0
    Camera Spectrum Angle is:      	 -0.01
    Camera Wavelength Factor is:   	 0.98
    Amplitude Threshold is:        	 0.2
    Wavelength Threshold is:       	 25



```python
################## STOP HERE STUDENT/INSTRUCTOR TO VALIDATE STEP 3 ####################
## IS THE ACTUAL EXPOSURE WITHIN THE TARGET LIMITS ??
## DID A RECTANGULAR WINDOW APPEAR OVERLAID ON THE IMAGE  ENCLOSING THE SPECTRUM ??
## IS THE SCAN LINE VISIBLE ??
## IS THE SCAN LINE ALIGNED WITH THE SLIT ??
## IF NOT WE HAVE TO MAKE ADJUSTMENTS BEFORE PROCEEDING
## READ INSTRUCTIONS IN VARIOUS CELLS ON THIS STEP
## MAKE CHANGES AND ASK FOR ME TO VALIDATE BEFORE PROCEEDING

# DO NOT GO FORWARD UNTIL INSTRUCTOR VALIDATES
```

## Display Emission Spectrum and Compare with NIST Standard values


```python
# STEP 4 FINAL STEP! NORMALIZE AND CREATE/DISPLAY SPECTRUM CHART
# MAKE ADJUSTMENTS AND RERUN FROM THE BEGINNING IF NEEDED
normalized_results = bdslibv2.normalize_results(results, max_result)
```


```python
#       Create the spectrum chart overlaid with the proper wavelengths 
#       and color map according to frequency
cht_png_filename = cht_filename + ".png"
bdslibv2.export_diagram(cht_png_filename, normalized_results)
```


```python
#display(Image(cht_png_filename))
#bdslibv2.display_bds_params(name,desc,shutter,slit_topadj,slit_botadj,spectrum_angle,wavelength_factor,samp_th,wlen_th)

```


```python
#       Print the Spectral Peaks table of wavelengths 
#       for current spectral image obtained
csv_tbl_filename = tbl_filename + ".csv"
bdslibv2.export_csv(tbl_filename, normalized_results)

#       Uncomment and change these thresholds if necessary if
#       you would like to increase or decrease the number
#       of Spectral peaks found

#samp_th = 0.2
#wlen_th = 10
#       Call function to draw the Spectral Peaks which will
#       Plot the peaks and return a list of Peak Wavelengths
pks_png_filename = pks_filename + ".png"
peak_wl, t1, t2 = bdslibv2.draw_spectral_line_peaks(element,csv_tbl_filename, pks_png_filename, desc, samp_th, wlen_th)
bdslibv2.display_bds_params(name,desc,shutter,slit_topadj,slit_botadj,spectrum_angle,wavelength_factor,samp_th,wlen_th)
par_txt_filename = par_filename + ".txt"
bdslibv2.write_bds_params(par_txt_filename,name,desc,shutter,slit_topadj,slit_botadj,spectrum_angle,wavelength_factor,samp_th,wlen_th)
```

    Title:		 SPECTRUM FROM A BRIGHT LED LIGHT SOURCE
    BDS parameters used for this run:
    Spectrum Base Name is          	 LED0731122116
    Camera Shutter is:             	 10000
    Slit Top Adjustment is:        	 50
    Slit Bottom Adjustment is:     	 0
    Camera Spectrum Angle is:      	 -0.01
    Camera Wavelength Factor is:   	 0.98
    Amplitude Threshold is:        	 0.2
    Wavelength Threshold is:       	 25



![png](output_33_1.png)



```python
pattern = pilimg.open(cht_png_filename).convert('RGBA')
#txt = pilimg.new('RGBA', pattern.size, (255,255,255,0))
size = width, height = pattern.size
draw = pildraw.Draw(pattern,'RGBA')
font = pilfont.truetype('/usr/share/fonts/truetype/lato/Lato-Regular.ttf', 12)
#print(size)
draw.text((0,0), desc.upper(), font=font, fill='#000')
draw.text((0,20), t1, font=font, fill='#000')
draw.text((0,40), t2, font=font, fill='#000')
#draw.text((0,100), "Hello World", (0, 0, 0, 0),font=font)
pattern.save(cht_png_filename)
```


```python

display(Image(cht_png_filename))
#bdslibv2.display_bds_params(name,desc,shutter,slit_topadj,slit_botadj,spectrum_angle,wavelength_factor,samp_th,wlen_th)
```


![png](output_35_0.png)



```python
camera.close()
```


```python
################## STOP HERE STUDENT/INSTRUCTOR TO VALIDATE STEP 4 FINAL STEP ####################
## CONGRATULATIONS - YOU MADE A FANCY DIGITAL SPECTROSCOPE AND MADE YOUR FIRST MEASUREMENTS!
## 
## DID THE SPECTRAL CHART APPEAR ??
## DOES THE CHART LOOK CORRECT ??
## DOES IT MATCH WITH THE STANDARD FOR ELEMENTS FOUND IN THE STANDARD SPECTRUM ??
## IF NOT WE WILL MAKE ADJUSTMENTS TO PARAMETERS ABOVE AS DOCUMENTED
## MAKE CHANGES AND ASK FOR ME TO VALIDATE BEFORE PROCEEDING

# DO NOT GO FORWARD UNTIL INSTRUCTOR VALIDATES
# WHEN YOU HAVE GOOD RESULTS PRINT FROM THE "FILE->PRINT PREVIEW" FROM
# THE JUPYTER NOTEBOOK AND GET THIS NOTEBOOK PRINTED FOR VALIDATION!
```
